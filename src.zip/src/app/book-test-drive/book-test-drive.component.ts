import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpServiceService } from '../http-service.service';

@Component({
  selector: 'app-book-test-drive',
  templateUrl: './book-test-drive.component.html',
  styleUrls: ['./book-test-drive.component.css']
})
export class BookTestDriveComponent implements OnInit {

  detailForm : any;
  showModal: boolean = false;
  firstName :any;
  lastName:any;
  constructor(private formBuilder: FormBuilder, private httpservice : HttpServiceService) {
    this.detailForm = this.formBuilder.group({
      firstname : ["",[Validators.required]],
      lastname : ["",[Validators.required]],
      phonenumber : ["",[Validators.required]],
      email : ["",[Validators.required]],
      age: ["",[Validators.required]],
      dob:["",[Validators.required]],
      city: ["",[Validators.required]],
      state:["",[Validators.required]],
      occupation: ["",[Validators.required]],
      model: ["",[Validators.required]],
    });
   }

   get firstname(){
     return this.detailForm.get('firstname');
   }
   get lastname(){
    return this.detailForm.get('lastname');
  }
  get email(){
    return this.detailForm.get('email');
  }
  get phonenumber(){
    return this.detailForm.get('phonenumber');
  }
  get age(){
    return this.detailForm.get('age');
  }
  get dob(){
    return this.detailForm.get('dob');
  }

  get city(){
    return this.detailForm.get('city');
  }
  get state(){
    return this.detailForm.get('state');
  }
  get occupation(){
    return this.detailForm.get('occupation');
  }

  get model(){
    return this.detailForm.get('model');
  }

  onSubmit(values:any)
  {
    console.log(values);
    this.firstName = values.firstname;
    this.lastName = values.lastname;
    this.showModal=true;
    this.httpservice.post("http://localhost:8000/details/",values).subscribe((res)=>{
      console.log(res);
    },
    (err)=>{
      console.log(err);
    })
  }

  ngOnInit(): void {
  }
  
  

}
