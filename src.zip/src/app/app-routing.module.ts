import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { BookTestDriveComponent } from './book-test-drive/book-test-drive.component';
import { CarListComponent } from './car-list/car-list.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';

const routes: Routes = [
  
  { path : "" , component : HomeComponent},
  {path : "prodcut", component : ProductComponent},
  {path : "product/:id", component:CarListComponent},
  { path : "about", component:AboutComponent },
  { path : "contact", component:ContactComponent },
  { path : "bookRide", component : BookTestDriveComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
