import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router'

@Component({
  selector: 'app-car-list',
  templateUrl: './car-list.component.html',
  styleUrls: ['./car-list.component.css']
})
export class CarListComponent implements OnInit {

  constructor(private router : Router, private activatedRoute : ActivatedRoute) { }
  item : any;
  carType:any;
  ngOnInit(): void {
    this.item = this.activatedRoute.params.subscribe(param=>{
      this.carType = param['id']
    }); 
  }

}
